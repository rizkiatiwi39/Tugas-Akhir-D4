Masukkan ke dalam Arduino/Library, library dimodifikasi untuk ESP32 Doit Devkit V1
